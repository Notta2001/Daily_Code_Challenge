import java.util.Scanner;

public class Student extends Person {
	String rollNo;
	float mark;
	String email;
	
	public Student() {
		
	}
	
	@Override
	public void inputInfo() {
		super.inputInfo();
		
		Scanner input = new Scanner(System.in);
		System.out.println("Nhap ma sinh vien : ");
		while(!setRollNo(input.nextLine()));
		
		System.out.println("Nhap diem trung binh : ");
		while(!setMark(input.nextFloat()));
		
		System.out.println("Nhap email : ");
		while(!setEmail(input.nextLine()));
		
	}

	public String getRollNo() {
		return rollNo;
	}

	public boolean setRollNo(String rollNo) {
		if(rollNo != null && rollNo.length() == 8) {
			this.rollNo = rollNo;
			return true;
		}
		else {
			System.err.println("Nhap lai ma sinh vien(MSSV chi co 8 ky tu) : ");
			return false;
		}
	}

	public float getMark() {
		return mark;
	}

	public boolean setMark(float mark) {
		if(mark >= 0 && mark <= 10) {
			this.mark = mark;
			return true;
		}
		else {
			System.err.println("Nhap sai diem, nhap lai diem(Diem lon hon bang 0 va nho hon 10): ");
			return false;
		}
	}

	public String getEmail() {
		return email;
	}

	public boolean setEmail(String email) {
		if(email.contains("@") && !email.contains(" ") && email != null) {
			this.email = email;
			return true;
		}
		else {
			System.err.print("Nhap lai dia chi email : ");
			return false;
		}
	}
	
	public boolean checkScholarship() {
		return mark >= 8;
	}
	
	@Override
	public void showInfo() {
		super.showInfo();
		System.out.print("; rollNo : " + rollNo + "; mark : " + mark + "; email : " + email);
		System.out.println("");
	}
}
