import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class StudentTest {
	public static void main(String[] args) {
		ArrayList<Student> StudentList = new ArrayList<>();
		int choose;
		try (Scanner scan = new Scanner(System.in)) {
			do {
				showMenu();
				System.out.println("Choose : ");
				choose = Integer.parseInt(scan.nextLine());
				
				switch(choose) {
					case 1:
						int n;
						System.out.println("Nhap so sinh vien can them : ");
						n = Integer.parseInt(scan.nextLine());
						for(int i = 0; i < n; ++i) {
							Student std = new Student();
							std.inputInfo();
							
							StudentList.add(std);
						}
						break;
						
					case 2:
						for(int i = 0; i < StudentList.size(); ++i) {
							StudentList.get(i).showInfo();
						}
						break;
						
					case 3:
						Student maxMark = StudentList.get(0);
						Student minMark = StudentList.get(0);
						
						for(Student student : StudentList) {
							if(student.getMark() > maxMark.getMark()) {
								maxMark = student;
							}
							if(student.getMark() < minMark.getMark()) {
								minMark = student;
							}
						}
						
						System.out.println("Sinh vien co diem trung binh cao nhat : ");
						maxMark.showInfo();
						
						System.out.println("Sinh vien co diem trung binh thap nhat  : ");
						minMark.showInfo();
						
						break;
						
					case 4:
						System.out.println("Nhap rollNo can tim kiem : ");
						String rollNoSearch = scan.nextLine();
						int count = 0;
						
						for(Student student : StudentList) {
							if(student.getRollNo().equalsIgnoreCase(rollNoSearch)) {
								student.showInfo();
								count ++;
							}
						}
						
						if(count == 0) {
							System.out.println("Khong tim thay sinh vien nao!");
						}
						break;
						
					case 5:
						// Sap xep ten the
						Collections.sort(StudentList, new Comparator<Student>() {

							@Override
							public int compare(Student o1, Student o2) {
								int cmp = o1.getName().compareTo(o2.getName());
								if(cmp >= 0) {
									return 1;
								}
								return -1;
							}
						});
						
						for(Student student : StudentList) {
							student.showInfo();
						}
						break;
						
					case 6:
						Collections.sort(StudentList, new Comparator<Student>() {

							@Override
							public int compare(Student o1, Student o2) {
								return o1.getMark() >= o2.getMark() ? -1 : 1;
							}
							
						});
						
						for(Student student : StudentList) {
							if(student.checkScholarship()) {
								student.showInfo();
							}
						}
						break;
						
					case 7:
						System.out.println("Goodbye!");
						break;
					default :
						System.err.println("Error!");
						break;
				}
			}while(choose != 7);
		}
	}
	
	static void showMenu() {
		System.out.println("1. Nhap vao N sinh vien");
		System.out.println("2. Hien thi thong tin sinh vien");
		System.out.println("3. Hien thi max va min theo diem trung binh");
		System.out.println("4. Tim kiem theo MSSV");
		System.out.println("5. Sort theo A-Z theo ten sinh vien va hien thi");
		System.out.println("6. Hien thi sinh vien duoc hoc bong va sap xep theo diem");
		System.out.println("7. Thoat");
	}
}
